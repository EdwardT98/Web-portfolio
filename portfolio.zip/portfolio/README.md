# Project Title

Web Portfolio

## Design Choices

This Web portfio was created with the help of Html, css, javascript, bootstrap, css library, isotope, and masonry js


### home Page

so i decided to go for something that stands out, i used an image of mysef in the front of the page and a text on top of it with this blue graident around the image it self, makes it look quite unique. the whole front of the page has mostly everything except for the gallery and the contact page. so the about page is also on the front page and everything else.


## About Page

About the about page. which is not really a page on its own, it just has a small section of its own on the front page and it basically just talks about myself and the experience i have in grpahic deisgn, how well i work with clients and why choosing me is a great choice.

## Gallery Page
for the gallery page i was going for something different. so each time you scrolled over an image it tells you the title of the image and when clicked you get a bigger image. This was achived by using isotope, masonry js.

### Contact Page

The contact page is quite straght foward. it just like any other contact page but it also has a map right under it which would show you the location.



### Reflection 
How: In my webportlio website i wanted the gallery to have a uniquie look when someone heads to the gallery page of the website. I wasnt sure exaclty how it would turn out or even if it would look good but i decided to try out a bunch of things and i think it turned out exaclty how i wanted it to.


## What I learned:
 Alot of errors and errors espically when using bootstrap and all these third party plugin, working with them was stressful but i would say it was worth it becuse the website turned out exactly how i wanted it to look.  I got alot of insipration from other peoples work so i had an idea of how I wanted it to look and thats what i did. 

## Built With
html,css and javscript, bootstrap, isotope masonary js.

## Author

Ifeoluwa Adewoye
